package LAB1;
import java.awt.*;
import java.awt.event.*;

public class Pizza {
	public static void main(String[] args) {
		 Frame frame = new Frame("Rocky Woodfired Pizza Management System");
	        frame.setSize(700, 350); // Increased height to accommodate the bill section

	        // Main panel with null layout
	        Panel panel = new Panel(null);
	        panel.setBackground(Color.LIGHT_GRAY);
	        frame.add(panel);

	        Label label = new Label("Rocky Woodfired Pizza Management System");
	        label.setBounds(10, 10, 600, 50);
	        Font font = new Font("TimesNewRoman", Font.PLAIN, 30);
	        label.setFont(font);
	        panel.add(label);

	        Label name = new Label("Customer Name :");
	        name.setBounds(50, 100, 150, 50);
	        Font font1 = new Font("TimesNewRoman", Font.PLAIN, 16);
	        name.setFont(font1);
	        panel.add(name);

	        TextField name1 = new TextField();
	        name1.setBounds(170, 100, 400, 40);
	        panel.add(name1);

	        Label topping = new Label("Number of Toppings");
	        topping.setBounds(50, 150, 150, 50);
	        topping.setFont(font1);
	        panel.add(topping);

	        TextField toppings = new TextField();
	        toppings.setBounds(200, 150, 120, 40);
	        panel.add(toppings);

	        // Create radio buttons
	        CheckboxGroup sizeGroup = new CheckboxGroup();
	        Checkbox small = new Checkbox("Small", sizeGroup, false);
	        Checkbox medium = new Checkbox("Medium", sizeGroup, false);
	        Checkbox large = new Checkbox("Large", sizeGroup, false);

	        // Set bounds for radio buttons
	        int checkboxY = 160;
	        small.setBounds(350, checkboxY, 80, 20); // Adjusted width
	        medium.setBounds(440, checkboxY, 80, 20); // Adjusted width
	        large.setBounds(530, checkboxY, 80, 20); // Adjusted width
	        panel.add(small);
	        panel.add(medium);
	        panel.add(large);

	        // Bill panel with white background
	        Panel billPanel = new Panel(null) {
	            @Override
	            public void paint(Graphics g) {
	                super.paint(g);
	                Graphics2D g2d = (Graphics2D) g;
	                g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0));
	                g2d.drawLine(50, 60, 130, 60); // Below Customer label
	                g2d.drawLine(200, 60, 280, 60); // Below Garments label
	                g2d.drawLine(350, 60, 430, 60); // Below Charge label
	            }
	        };
	        billPanel.setBackground(Color.WHITE);
	        billPanel.setBounds(10, 210, 660, 100); // Adjusted size and position
	        panel.add(billPanel);

	        // Bill section labels
	        Label billLabel = new Label("Bill Section");
	        billLabel.setBounds(10, 0, 100, 30); // Adjusted position
	        billLabel.setFont(font1);
	        billPanel.add(billLabel);

	        Label customerLabel = new Label("Customer:");
	        customerLabel.setBounds(50, 40, 100, 20); // Adjusted position
	        billPanel.add(customerLabel);

	        Label garmentsLabel = new Label("Garments:");
	        garmentsLabel.setBounds(200, 40, 100, 20); // Adjusted position
	        billPanel.add(garmentsLabel);

	        Label chargeLabel = new Label("Charge:");
	        chargeLabel.setBounds(350, 40, 100, 20); // Adjusted position
	        billPanel.add(chargeLabel);

	        // Text below labels
	        Label customerText = new Label("Santosh");
	        customerText.setBounds(50, 70, 100, 20); // Adjusted position
	        billPanel.add(customerText);

	        Label garmentsText = new Label("5");
	        garmentsText.setBounds(200, 70, 100, 20); // Adjusted position
	        billPanel.add(garmentsText);

	        Label chargeText = new Label("$16.75");
	        chargeText.setBounds(350, 70, 100, 20); // Adjusted position
	        billPanel.add(chargeText);

	        Label avgGarmentsLabel = new Label("Average garments per order:");
	        avgGarmentsLabel.setBounds(50,80, 200, 20);
	        billPanel.add(avgGarmentsLabel);

	        Label avgGarmentsValue = new Label("5");
	        avgGarmentsValue.setBounds(250, 90, 50, 20);
	        billPanel.add(avgGarmentsValue);

	        // Total charge label
	        Label totalChargeLabel = new Label("Total Charge:");
	        totalChargeLabel.setBounds(350, 90, 100, 20);
	        billPanel.add(totalChargeLabel);

	        Label totalChargeValue = new Label("$16.75");
	        totalChargeValue.setBounds(450, 90, 100, 20);
	        billPanel.add(totalChargeValue);

	        // Buttons
	        Button enterButton = new Button("Enter");
	        enterButton.setBounds(50, 370, 80, 30);
	        panel.add(enterButton);

	        Button displayAllButton = new Button("Display All");
	        displayAllButton.setBounds(150, 370, 80, 30);
	        panel.add(displayAllButton);

	        Button searchButton = new Button("Search");
	        searchButton.setBounds(250, 370, 80, 30);
	        panel.add(searchButton);

	        Button exitButton = new Button("Exit");
	        exitButton.setBounds(350, 370, 80, 30);
	        panel.add(exitButton);
	        
	        frame.setVisible(true);

	        frame.addWindowListener(new WindowAdapter() {
	            public void windowClosing(WindowEvent e) {
	                frame.dispose();
	            }
	        });
	    }
	}	