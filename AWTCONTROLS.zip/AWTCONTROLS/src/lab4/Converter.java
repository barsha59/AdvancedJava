package lab4;
import javax.swing.*;

public class Converter  extends JFrame implements keyListener{
	JLabel cel,Fah;
	JTextField CelValue, FahValue;
	JButton Convert;
	
	public Converter() {
		
		JPanel p=new JPanel();
		
		cel=new JLabel("Enter temperature in Celcius");
		CelValue=new JTextField(10);
		
		Fah=new JLabel("Temperature in Fahrenheit");
		FahValue=new JTextField(10);
		
		Convert=new JButton("Convert");
		
		p.add(cel);
		p.add(CelValue);
		p.add(Fah);
		p.add(FahValue);
		p.add(Convert);
		
		add(p);
		setVisible(true);
		
		
		
	}
	

}
