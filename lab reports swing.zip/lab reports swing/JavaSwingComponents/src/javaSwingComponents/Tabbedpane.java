package javaSwingComponents;

import javax.swing.*;
import java.awt.*;

public class Tabbedpane {

    public static void main(String[] args) {
     
        JFrame frame = new JFrame("TabbedPane");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        

        JTabbedPane tabbedPane = new JTabbedPane();

 
        JPanel homePanel = new JPanel();
        JLabel homeLabel = new JLabel("Welcome to the Home Tab!");
        homePanel.add(homeLabel);
        tabbedPane.addTab("Home", homePanel);
      
        JPanel profilePanel = new JPanel(new GridLayout(2, 2));
        JLabel nameLabel = new JLabel("Name: ");
        JTextField nameTextField = new JTextField();
        JLabel emailLabel = new JLabel("Email: ");
        JTextField emailTextField = new JTextField();
        profilePanel.add(nameLabel);
        profilePanel.add(nameTextField);
        profilePanel.add(emailLabel);
        profilePanel.add(emailTextField);
        tabbedPane.addTab("Profile", profilePanel);
        

        JPanel settingsPanel = new JPanel();
        JLabel settingsLabel = new JLabel("Settings");
        JButton settingsButton = new JButton("Apply");
        settingsPanel.add(settingsLabel);
        settingsPanel.add(settingsButton);
        tabbedPane.addTab("Settings", settingsPanel);

  
        frame.add(tabbedPane);
 
        frame.setVisible(true);
    }
}



