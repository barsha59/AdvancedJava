package javaSwingComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class convert {

    public static void main(String[] args) {
     
        JFrame frame = new JFrame("Celsius to Fahrenheit Converter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 100);
        
       
        frame.setLayout(new GridLayout(2, 2));
        
       
        JLabel celsiusLabel = new JLabel("Celsius: ");
        JTextField celsiusTextField = new JTextField();
        JLabel fahrenheitLabel = new JLabel("Fahrenheit: ");
        JTextField fahrenheitTextField = new JTextField();
    

      
        celsiusTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                try {
                    String celsiusText = celsiusTextField.getText();
                    double celsius = Double.parseDouble(celsiusText);
                    
                    
                    double fahrenheit = celsius * 9 / 5 + 32;
                    
                 
                    fahrenheitTextField.setText(String.format("%.2f", fahrenheit));
                } catch (NumberFormatException ex) {
                   
                    fahrenheitTextField.setText("");
                }
            }
        });
        
        frame.add(celsiusLabel);
        frame.add(celsiusTextField);
        frame.add(fahrenheitLabel);
        frame.add(fahrenheitTextField);
        
 
        frame.setVisible(true);
    }
}
